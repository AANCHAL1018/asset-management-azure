window.applyTheme = (theme) => {
  document.documentElement.className = theme;
};
